/*
 * Vencord, a Discord client mod
 * Claude Translate - Translate messages using Claude AI via local Claude Code
 * Copyright (c) 2026 Nyarc
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { ApplicationCommandInputType, ApplicationCommandOptionType, findOption, sendBotMessage } from "@api/Commands";
import definePlugin, { OptionType } from "@utils/types";
import { definePluginSettings } from "@api/Settings";

// ── Native bridge ──────────────────────────────────────────────
// native.ts runs in Node.js → can spawn claude CLI
const Native = VencordNative.pluginHelpers.ClaudeTranslate as {
    translateWithClaude(style: string, text: string): Promise<string>;
};

// ── Style presets ──────────────────────────────────────────────
const STYLES: Record<string, string> = {
    shakespeare:
        "Rewrite the following text in elaborate Shakespearean / Early Modern English. " +
        "Use thee/thou/thy, archaic verb forms (-eth, -est), and flowery metaphors. " +
        "Keep the original meaning intact. Output ONLY the translated text, nothing else.",
    pirate:
        "Rewrite the following text as a stereotypical pirate would say it. " +
        "Use 'arr', 'ye', 'matey', nautical terms, etc. " +
        "Output ONLY the translated text, nothing else.",
    medieval:
        "Rewrite the following text in a medieval style, as if spoken by a knight or noble. " +
        "Use 'prithee', 'forsooth', 'hark', formal address. " +
        "Output ONLY the translated text, nothing else.",
    yoda:
        "Rewrite the following text in the speech pattern of Yoda from Star Wars. " +
        "Invert sentence structure. " +
        "Output ONLY the translated text, nothing else.",
    formal:
        "Rewrite the following text in extremely formal, diplomatic English. " +
        "Output ONLY the translated text, nothing else.",
    uwu:
        "Rewrite the following text in 'uwu' internet speak. " +
        "Replace r/l with w, add stuttering, add emoticons like OwO, UwU, >w<. " +
        "Output ONLY the translated text, nothing else.",
};

const styleChoices = Object.keys(STYLES).map(s => ({
    name: s,
    displayName: s.charAt(0).toUpperCase() + s.slice(1),
    value: s,
}));

// ── Settings ───────────────────────────────────────────────────
const settings = definePluginSettings({
    sendAsMessage: {
        type: OptionType.BOOLEAN,
        description: "Send translation as a real message (visible to others) instead of a local bot message",
        default: false,
    },
});

// ── Plugin ─────────────────────────────────────────────────────
export default definePlugin({
    name: "ClaudeTranslate",
    description: "Translate messages into fun styles (Shakespeare, Pirate, Yoda, etc.) using your local Claude Code installation",
    authors: [{ name: "Nyarc", id: 0n }],
    dependencies: ["CommandsAPI"],
    settings,

    commands: [
        {
            name: "translate",
            description: "Translate text into a fun language style via Claude",
            inputType: ApplicationCommandInputType.BUILT_IN,
            options: [
                {
                    name: "style",
                    description: "Translation style",
                    type: ApplicationCommandOptionType.STRING,
                    required: true,
                    choices: styleChoices,
                },
                {
                    name: "text",
                    description: "The text to translate",
                    type: ApplicationCommandOptionType.STRING,
                    required: true,
                },
            ],

            async execute(args, ctx) {
                const style = findOption<string>(args, "style", "shakespeare");
                const text = findOption<string>(args, "text", "");

                if (!text) {
                    return sendBotMessage(ctx.channel.id, {
                        content: "❌ Please provide some text to translate.",
                    });
                }

                // Show a "thinking" message
                sendBotMessage(ctx.channel.id, {
                    content: `🔄 Translating to **${style}**...`,
                });

                try {
                    const result = await Native.translateWithClaude(
                        STYLES[style] ?? STYLES.shakespeare,
                        text
                    );

                    const cleaned = result.trim();

                    if (settings.store.sendAsMessage) {
                        // Send as a real message (others can see it)
                        return { content: cleaned };
                    } else {
                        // Send as local-only bot message (only you see it)
                        return sendBotMessage(ctx.channel.id, {
                            content: `🎭 **${style.toUpperCase()}**:\n${cleaned}`,
                        });
                    }
                } catch (e: any) {
                    return sendBotMessage(ctx.channel.id, {
                        content: `❌ Translation failed: ${e?.message ?? "Unknown error"}\n\nMake sure Claude Code is installed and accessible via the \`claude\` command in your terminal.`,
                    });
                }
            },
        },
    ],
});
