/*
 * Vencord, a Discord client mod
 * Claude Translate - Native bridge (runs in Node.js, NOT browser)
 * Copyright (c) 2026 Nyarc
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

/**
 * Calls `claude` CLI with a translation prompt.
 * This runs in Node.js so we can use child_process.
 *
 * @param style  - The system prompt describing the translation style
 * @param text   - The user's text to translate
 * @returns        The translated text from Claude
 */
export async function translateWithClaude(
    _: any,           // IPC event (unused but required by Vencord native bridge)
    style: string,
    text: string
): Promise<string> {
    // Escape single quotes in the text to prevent shell injection
    const escapedText = text.replace(/'/g, "'\\''");
    const escapedStyle = style.replace(/'/g, "'\\''");

    const fullPrompt = `${escapedStyle}\n\nText to translate:\n${escapedText}`;

    try {
        // --print (-p) = non-interactive mode, just outputs the response
        const { stdout, stderr } = await execAsync(
            `claude -p '${fullPrompt}'`,
            {
                timeout: 30000,  // 30 second timeout
                maxBuffer: 1024 * 1024,
                env: { ...process.env },
            }
        );

        if (stderr && !stdout) {
            throw new Error(stderr.trim());
        }

        return stdout.trim();
    } catch (e: any) {
        // If claude command not found, give a helpful error
        if (e?.code === 127 || e?.message?.includes("not found")) {
            throw new Error(
                "Claude Code CLI not found. Install it with: npm install -g @anthropic-ai/claude-code"
            );
        }
        throw new Error(e?.message ?? "Failed to run Claude Code");
    }
}
